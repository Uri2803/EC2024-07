+ npm install express
+ npm install --save-dev @babel/core @babel/cli @babel/preset-env @babel/node (compiler)
+ npm install --save-dev nodemon (tự động start server)
+ npm install dotenv 
+ npm install body-parser
+ npm install cors
+ npm install express-session
+ npm install express mysql2

